package com.programming.techie.springredditclone.repository;

import com.programming.techie.springredditclone.BaseTest;
import com.programming.techie.springredditclone.model.Post;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
//@Testcontainers // JUnit, see BaseTest.java
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE) // for not replace our database
public class PostRepositoryTest extends BaseTest {

    // instance container MySQL database from: \test\java\com\programming\techie\springredditclone\BaseTest.java
	
    @Autowired
    private PostRepository postRepository;

    /*
    test to create a new Post Object and asserting whether it’s saved correctly to the database or not.
     */
    @Test
    public void shouldSavePost() {
        Post expectedPostObject = new Post(null, "First Post", "http://url.site", "Test",
                0, null, Instant.now(), null);
        Post actualPostObject = postRepository.save(expectedPostObject);
        assertThat(actualPostObject).usingRecursiveComparison()
                .ignoringFields("postId").isEqualTo(expectedPostObject);
    }
}
