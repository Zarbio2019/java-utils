package com.programming.techie.springredditclone;

import org.testcontainers.containers.MySQLContainer;

public abstract class BaseTest {
	
	/*
	This initialization of MySQLContainer is moved here to avoid increase of time when running various
	tests (PostRepositoryTest.java and UserRepositoryTest.java) and avoid that MySQL TestContainer is starting up two times.
	For that is also needed:
		1. remove @Testcontainers and @Container from our tests.
		2. Follow the singleton container approach:
		https://java.testcontainers.org/test_framework_integration/manual_lifecycle_control/
		By using the singleton container approach, we just have to move the logic of initializing the containers to an
		Abstract class, and make our Tests extend this abstract class.
		
	we are initializing a MySQLContainer by providing the docker image name, and the required database information.
    
    Be careful to not use the username as root when configuring the MySQLContainer, as the root username already exists in MySQL.
	 
	- If you try to run both these tests together, you can observe a warning message like below in your tests:
	22:40:31.807 [main] WARN 🐳 [mysql:latest] – Reuse was requested but the environment does not support the reuse of containers
	
	Solution:
	you have to change the .testcontainer.properties file inside your user home folder C:\Users\<username>\.testcontainers.properties, and add the property testcontainers.reuse.enable=true
	 */
	// mysql:latest: docker image
	// spring-reddit-test-db: MySQL database name
	//@Container // to instance a container for testing
    static MySQLContainer mySQLContainer = (MySQLContainer) new MySQLContainer("mysql:latest")
            .withDatabaseName("spring-reddit-test-db")
            .withUsername("testuser")
            .withPassword("pass")
            .withReuse(true);

    static {
        mySQLContainer.start(); // executed only once
    }
}
