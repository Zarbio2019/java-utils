package com.programming.techie.springredditclone.service;

import com.programming.techie.springredditclone.exceptions.SpringRedditException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class CommentServiceTest {

    @Test
    @DisplayName("Test Should Pass When Comment do not Contains Swear Words")
    public void shouldNotContainSwearWordsInsideComment() {
        CommentService commentService = new CommentService(null, null, null, null, null, null, null);
        
        // method 1: with AssertJ library (is more readable)
        assertThat(commentService.containsSwearWords("This is a comment")).isFalse();

        // method 2: JUnit 5 built-in Assertions
//        assertFalse(commentService.containsSwearWords("This is a comment"));
    }

    @Test
    @DisplayName("Should Throw Exception when Exception Contains Swear Words")
    public void shouldFailWhenCommentContainsSwearWords() {
        CommentService commentService = new CommentService(null, null, null, null, null, null, null);

        // method 1: with AssertJ library (is more readable)
        assertThatThrownBy(() -> {
            commentService.containsSwearWords("This is a shitty comment");
        }).isInstanceOf(SpringRedditException.class)
                .hasMessage("Comments contains unacceptable language");

        // method 2: JUnit 5 built-in Assertions
        // we are expecting our method throw a SpringRedditException with a message "Comments contains unacceptable language"
//        SpringRedditException exception = assertThrows(SpringRedditException.class, () -> {
//            commentService.containsSwearWords("This is shitty comment");
//        });
//        assertTrue(exception.getMessage().contains("Comments contains unacceptable language"));
    }
}


