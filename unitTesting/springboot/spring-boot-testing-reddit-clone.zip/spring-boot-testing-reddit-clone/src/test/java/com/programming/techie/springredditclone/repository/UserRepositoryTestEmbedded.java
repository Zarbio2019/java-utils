package com.programming.techie.springredditclone.repository;

import com.programming.techie.springredditclone.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;

import java.time.Instant;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest // to bootstrap JPA related classes in our Test
@ActiveProfiles("test") // application-test.properties for h2 database
public class UserRepositoryTestEmbedded {

    @Autowired
    private UserRepository userRepository;
    
    @BeforeEach
    public void setup() {
    	// inserting Test data into the database from object
    	// to test shouldSaveUser()
//        User user = new User(null, "test user", "secret password", "user@email.com", Instant.now(), true);
//        User savedUser = userRepository.save(user);
    }
    
    /*
    test to check whether we are able to save a user to the database or not.
     */
    @Test
    public void shouldSaveUser() {
        User user = new User(null, "test user", "secret password", "user@email.com", Instant.now(), true);
        User savedUser = userRepository.save(user);
        assertThat(savedUser).usingRecursiveComparison().ignoringFields("userId").isEqualTo(user);
    }

    /*
    test the database logic.
    inserting Test data into the database from script test-data.sql (src/main/test/resources folder).
     */
    @Test
    @Sql("classpath:test-data.sql") // pre-populate data, execute the query to testing
    public void shouldSaveUsersThroughSqlFile() {
        Optional<User> test = userRepository.findByUsername("testuser_sql");
        assertThat(test).isNotEmpty();
    }
}
